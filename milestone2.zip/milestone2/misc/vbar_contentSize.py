import pandas as pd
from matplotlib import pyplot as plt
import plotly.express as px
import numpy as np

csv = pd.read_csv('archive.csv', header = 0)

#echo "Direction,Interchange Sender Qualifier,Interchange Sender,Interchange Receiver Qualifier,Interchange Receiver,Interchange Control Number,Interchange Date,Interchange Time,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size" > archive.csv

#csv_clean = csv.astype({'Direction': 'category','Interchange Sender': 'category','Interchange Receiver': 'category','Group Sender': 'category','Group Receiver': 'category','Group Type': 'category','Group Version': 'category','Message Type': 'category'})

csv_clean = csv.astype({'Direction': 'category','Interchange Sender': 'category','Interchange Receiver': 'category','Group Sender': 'category','Group Receiver': 'category','Group Type': 'category','Group Version': 'category','Message Type': 'category'})
fig = px.bar(csv_clean, x="Interchange Date", y="Content Size", color='Message Type', title='Bytes by Date and Document Type')
fig.write_html("test.html")
