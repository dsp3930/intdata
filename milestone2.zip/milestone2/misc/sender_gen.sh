cat archive.csv|cut -f5 -d "," > sender.tbl
