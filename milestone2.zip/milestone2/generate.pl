#!/usr/bin/perl
#
# Author: David Pitttman
# Version: 1
# Date: April 15, 2023
##########################
#Direction,Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name
#ZZ:WMT,ZZ:AMZN,000007418,2009-01-05 11:12:00,WMT,AMZN,PO,5209,004010,850,3,40,3172,2009,01,05,01,Monday

use CGI;
use Time::Local;
use Data::GUID;

# Generate a new GUID
my $guid = Data::GUID->new();
$id = $guid->as_string();

# create new CGI object
my $cgi = CGI->new;

# set content type
print $cgi->header('text/html');

# print HTML header
print "<html><head><title>Form Input Example</title></head><body>\n";

# check if form has been submitted
if ($cgi->param()) {
  # retrieve form data
  my $sender = $cgi->param('sender');
  my $receiver = $cgi->param('receiver');
  my $doctype = $cgi->param('doctype');
  my $uom = $cgi->param('uom');
  my $date = $cgi->param('date');
  my $compare = $cgi->param('compare');

  # print form data
  print "<p>Sender: $sender</p>\n";
  print "<p>Receiver: $receiver</p>\n";
  print "<p>DocType: $doctype</p>\n";
  print "<p>Unit of Measure: $uom</p>\n";
  print "<p>Date: $date</p>\n";
  print "<p>Compare: $compare</p>\n";
  #my $one_week_ago = one_week_ago($date);
  #print "<p>One Week Ago Date: $one_week_ago</p>\n";

#Generate regex for archive query
my @tmp = split(/\,/,$sender);
$sndr = $tmp[0];
my @tmp = split(/\,/,$receiver);
$rcvr = $tmp[0];
my @tmp = split(/\,/,$doctype);
$doc = $tmp[0];
if ($sndr eq "Any") {$sndr=".*";}
if ($rcvr eq "Any") {$rcvr=".*";}
if ($doc eq "Any") {$doc=".*";}

#print "<br>$sndr\n";
#print "<br>$rcvr\n";
#print "<br>$doc\n";

my $regexQuery = "$sndr\,$rcvr\,.*\,$date.*\,.*\,.*\,.*\,.*\,.*\,$doc\,";
#my $regexQuery = "$sndr\,$rcvr\,.*\,.*,.*\,.*\,.*\,.*\,.*\,$doc\,";

# Filter items from CSV archive and output to temp csv file tmp/GUID.csv
$filteredFile = grepArchive($regexQuery,$id);

plotlyGen($id);

}
# print HTML footer
print "</body></html>\n";

sub one_week_ago {
    my ($date_string) = @_;

    # Parse the input date
    my ($year, $month, $day) = split('-', $date_string);

    # Get the day of the week (0=Sunday, 1=Monday, etc.)
    my $day_of_week = (localtime(timelocal(0, 0, 0, $day, $month - 1, $year - 1900)))[6];

    # Subtract 1 week (604800 seconds)
    my $one_week_ago_timestamp = timelocal(0, 0, 0, $day - 7, $month - 1, $year - 1900);
    my $one_week_ago_day_of_week = (localtime($one_week_ago_timestamp))[6];

    # Check if the resulting date is the same day of the week
    if ($day_of_week == $one_week_ago_day_of_week) {
        my ($new_year, $new_month, $new_day) = (localtime($one_week_ago_timestamp))[5, 4, 3];
        $new_year += 1900;
        $new_month += 1;
        my $new_date_string = sprintf('%04d-%02d-%02d', $new_year, $new_month, $new_day);
        return $new_date_string;
    } else {
        return undef;
    }
}





################################################################################### SUBS





# Search for provided pattern within archive
sub grepArchive {
	use Data::GUID;

# Generate a new GUID
my $guid = Data::GUID->new();

# Print the GUID as a string
my $search_value = shift @_;
my $id = shift @_;
my $filename = "/home/dsp3930/nginx/tables/archive.csv";
open(FILTER,">/home/dsp3930/tmp/$id.csv");
#print "<br>$search_value\n";

open(my $fh, "<", $filename) or die "Can't open file: $!";
print FILTER "Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name\n";
while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /$search_value/) {
        print FILTER "$line\n";
    }
}
return $id;

close $fh;
close(FILTER);
}


sub plotlyGen {
my $id = shift @_;
# Execute python plotly program
my $output = qx(/usr/bin/python3.9 /home/dsp3930/intdata/today.py $id);
#print "<br> /home/dsp3930/intdata/today.py $id\n";
# Print the output to the console
open(FILE,"</home/dsp3930/tmp/$id.html");
while ($x = <FILE>) {
print $x;
}
close(FILE);
#unlink("/home/dsp3930/tmp/$id.html");
}
