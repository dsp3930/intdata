#!/usr/bin/python3.9
import plotly
import plotly.express as px
import pandas as pd
import sys

id = sys.argv[1]

# read in CSV file
csv = f'/home/dsp3930/tmp/{id}.csv'
df = pd.read_csv(csv)

#Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name

df_clean = df.astype({'Interchange Sender': 'category','Interchange Receiver': 'category','Group Sender': 'category','Group Receiver': 'category','Group Type': 'category','Group Version': 'category','Message Type': 'category'})
#fig = px.line(df_clean, x="Interchange Timestamp", y="Content Size", color='Message Type', title='Message Type by Date')
fig = px.area(df_clean, x="Interchange Timestamp", y="Content Size", color='Message Type', title='Message Type by Date')
#fig = px.bar(df_clean, x="Interchange Timestamp", y="Content Size", color='Message Type', title='Message Type by Date')
#fig = px.scatter(df_clean, x="Interchange Timestamp", y="Content Size", color='Message Type', title='Message Type by Date')

# Save the chart as an image
htmlOutput = f'/home/dsp3930/tmp/{id}.html'
fig.write_html(htmlOutput)
