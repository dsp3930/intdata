#!/usr/bin/perl
#
# Author: David Pitttman
# Version: 1
# Date: April 15, 2023
# Notes: Original base CGI code by ChatGPT query.
# 1) Compare date specified and prior same weekday
# 2) Compare date specified and prior month's same weekday
# 3) Compare date and average of all prior same weekdays of the same moth 
# 3) Compare date and average of all prior same weekdays of the prior month
# 4) Future ehancement if realtime data is available and more than 1 quarter.  Compare date and same weekday last year.
##########################
#Direction,Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name
#ZZ:WMT,ZZ:AMZN,000007418,2009-01-05 11:12:00,WMT,AMZN,PO,5209,004010,850,3,40,3172,2009,01,05,01,Monday

use CGI;
use Time::Local;
use Data::GUID;

# Generate a new GUID
my $guid = Data::GUID->new();
$id = $guid->as_string();

# create new CGI object
my $cgi = CGI->new;

# set content type
print $cgi->header('text/html');

# print HTML header
print "<html><head><title>EDI Archive Graphical Volume Viewer</title></head><body>\n";
print "<h2>EDI Archive Graphical Volume Viewer</h2>\n";
print "<hr>\n";

# check if form has been submitted
if ($cgi->param()) {
  # retrieve form data
  my $sender = $cgi->param('sender');
  my $receiver = $cgi->param('receiver');
  my $doctype = $cgi->param('doctype');
  #my $uom = $cgi->param('uom');
  my $date = $cgi->param('date');
  my $chart = $cgi->param('chart');

  $sndr = $sender;
  $rcvr = $receiver;
  $doc = $doctype;

  $sndr =~ s/.*\,//g;
  $rcvr =~ s/.*\,//g;
  $doc =~ s/\,/ /g;

  # print form data
  print "<p>Sender: $sndr</p>\n";
  print "<p>Receiver: $rcvr</p>\n";
  print "<p>DocType: $doc</p>\n";
  #  print "<p>Unit of Measure: $uom</p>\n";
  print "<p>Date: $date</p>\n";
  print "<p>Chart Type: $chart</p>\n";
  print "<hr>\n";
  #my $one_week_ago = one_week_ago($date);
  #print "<p>One Week Ago Date: $one_week_ago</p>\n";

#Generate regex for archive query
my @tmp = split(/\,/,$sender);
$sndr = $tmp[0];
my @tmp = split(/\,/,$receiver);
$rcvr = $tmp[0];
my @tmp = split(/\,/,$doctype);
$doc = $tmp[0];
if ($sndr eq "Any") {$sndr=".*";}
if ($rcvr eq "Any") {$rcvr=".*";}
if ($doc eq "Any") {$doc=".*";}

#print "<br>$sndr\n";
#print "<br>$rcvr\n";
#print "<br>$doc\n";

#my $regexQuery = "$sndr\,$rcvr\,.*\,$date.*\,.*\,.*\,.*\,.*\,.*\,$doc\,";
my $regexQuery = "$sndr\,$rcvr\,.*\,.*\,.*\,.*\,.*\,.*\,.*\,$doc\,";
#my $regexQuery = "$sndr\,$rcvr\,.*\,.*,.*\,.*\,.*\,.*\,.*\,$doc\,";

# Filter items from CSV archive and output to temp csv file tmp/GUID.csv
$filteredFile = grepArchive($regexQuery,$id);

plotlyGen($id,$date,$chart);

}
# print HTML footer
print "</body></html>\n";

sub one_week_ago {
    my ($date_string) = @_;

    # Parse the input date
    my ($year, $month, $day) = split('-', $date_string);

    # Get the day of the week (0=Sunday, 1=Monday, etc.)
    my $day_of_week = (localtime(timelocal(0, 0, 0, $day, $month - 1, $year - 1900)))[6];

    # Subtract 1 week (604800 seconds)
    my $one_week_ago_timestamp = timelocal(0, 0, 0, $day - 7, $month - 1, $year - 1900);
    my $one_week_ago_day_of_week = (localtime($one_week_ago_timestamp))[6];

    # Check if the resulting date is the same day of the week
    if ($day_of_week == $one_week_ago_day_of_week) {
        my ($new_year, $new_month, $new_day) = (localtime($one_week_ago_timestamp))[5, 4, 3];
        $new_year += 1900;
        $new_month += 1;
        my $new_date_string = sprintf('%04d-%02d-%02d', $new_year, $new_month, $new_day);
        return $new_date_string;
    } else {
        return undef;
    }
}





################################################################################### SUBS





# Search for provided pattern within archive
sub grepArchive {
	use Data::GUID;

# Generate a new GUID
my $guid = Data::GUID->new();

# Print the GUID as a string
my $search_value = shift @_;
my $id = shift @_;
my $filename = "/home/dsp3930/nginx/tables/archive.csv";
open(FILTER,">/home/dsp3930/tmp/$id.csv");
#print "<br>$search_value\n";

open(my $fh, "<", $filename) or die "Can't open file: $!";
print FILTER "Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,Content Size,Year,Month,Day,Week of Year,Day Name\n";
while (my $line = <$fh>) {
    chomp $line;
    if ($line =~ /$search_value/) {
        print FILTER "$line\n";
    }
}
return $id;

close $fh;
close(FILTER);
}


sub plotlyGen {
my $id = shift @_;
my $date = shift @_;
my $chart = shift @_;
# Execute python plotly program
if ($chart eq "Line")
{my $output = qx(/usr/bin/python3.9 /home/dsp3930/intdata/line.py $id $date);}
else
{print "<br>Invalid Chart Type: $chart\n";}
#print "<br> /home/dsp3930/intdata/today.py $id $date\n";
# Print the output to the console
open(FILE,"</home/dsp3930/tmp/$id.html")|| print "<br>File not found\n"; 
while ($x = <FILE>) {
print $x;
}
close(FILE);
#unlink("/home/dsp3930/tmp/$id.html");
}

sub testGen {
my $id = shift @_;
my $date = shift @_;
print "<br>$date\n";
}
