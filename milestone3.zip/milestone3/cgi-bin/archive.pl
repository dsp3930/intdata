#!/usr/bin/perl
#
# Author: David Pitttman
# Version: 1
# Date: April 15, 2023
# Notes: Original base CGI code by ChatGPT query.
#
#
##########################

use strict;
use CGI qw(:standard);

# File paths for select tables
my $file1 = "/home/dsp3930/nginx/tables/sender.tbl";
my $file2 = "/home/dsp3930/nginx/tables/receiver.tbl";
my $file3 = "/home/dsp3930/nginx/tables/doctype.tbl";
my $file4 = "/home/dsp3930/nginx/tables/uom.tbl";
my $file5 = "/home/dsp3930/nginx/tables/x12.tbl";
my $file6 = "/home/dsp3930/nginx/tables/chart.tbl";

# Read in values from files
open my $fh1, '<', $file1 or die "Cannot open $file1: $!";
my @list1 = <$fh1>;
close $fh1;

open my $fh2, '<', $file2 or die "Cannot open $file2: $!";
my @list2 = <$fh2>;
close $fh2;

open my $fh3, '<', $file3 or die "Cannot open $file3: $!";
my @list3 = <$fh3>;
close $fh3;

open my $fh4, '<', $file4 or die "Cannot open $file4: $!";
my @list4 = <$fh4>;
close $fh4;

open my $fh5, '<', $file5 or die "Cannot open $file5: $!";
my @list5 = <$fh5>;
close $fh5;

open my $fh6, '<', $file6 or die "Cannot open $file6: $!";
my @list6 = <$fh6>;
close $fh6;

# Create form
print header;
print start_html('EDI Archive Graphical Volume Viewer');
print "<h2>EDI Archive Graphical Volume Viewer</h2>\n";
print "<hr>\n";
print "<form method='post' action='generate.pl'>\n";


# Sender select list
print "<label for='list1'>Sender:</label>\n";
print "<select name='sender'>\n";
print "<option value='Any,Any'>Any</option>\n";
foreach my $option (@list1) {
  chomp $option;
  my $optionDisplay = $option;
  $optionDisplay =~ s/,/ /g;
  print "<option value='$option'>$optionDisplay</option>\n";
}
print "</select>\n";

# Receiver select
print "<label for='list2'>Receiver:</label>\n";
print "<select name='receiver'>\n";
print "<option value='Any,Any'>Any</option>\n";
foreach my $option (@list2) {
  chomp $option;
  my $optionDisplay = $option;
  $optionDisplay =~ s/,/ /g;
  print "<option value='$option'>$optionDisplay</option>\n";
}
print "</select>\n";

print "<p>\n";
# DocType select
print "<label for='list3'>DocType:</label>\n";
print "<select name='doctype'>\n";
#print "<option value='Any,Any'>Any</option>\n";
foreach my $option (@list3) {
  chomp $option;
  my $optionDisplay = $option;
  $optionDisplay =~ s/,/ /;
  print "<option value='$option'>$optionDisplay</option>\n";
}
print "</select>\n";

# Date select
print "<label for='date'>Date of Interest:</label>\n";
print "<input type='date' min='2009-01-05' max='2009-04-25' value='2009-01-27' name='date' required>\n";
print "</select>\n";

# UOM select
#print "<label for='list4'>Unit of Measure:</label>\n";
#print "<select name='uom'>\n";
#foreach my $option (@list4) {
#  chomp $option;
#  print "<option value='$option'>$option</option>\n";
#}
#print "</select>\n";

# Report Type 
print "<label for='list6'>Chart Type:</label>\n";
print "<select name='chart'>\n";
foreach my $option (@list6) {
  chomp $option;
  print "<option value='$option'>$option</option>\n";
}
print "</select>\n";

# Reset and Submit
print "<p>\n";
print "<input type='reset' value='Reset'> <input type='submit' value='Submit'>\n";

print "</form>\n";
print end_html;
