##################################################################
Milestone 2 - April 10, 2023########################################################################
##################################################################

March 18, 2023
 8H Reviewed Python+Ploty and worked with misc tests. This was to confirm I was comfortable with it and could generate reasonable results. Then, generated project proposal.
 This included: pie_messageCount.py  vbar_contentSize.py  vbar_messageCount.py  vbar_messageType.py
 Obtained an EDI archive from a period in 2009 for a client I worked with and created a Perl program (archiveInfo.pl) to process the data into csv format.
March 19, 2023
 4H Rreviewed concepts for CGI processing of user input 
 2H Created rough code for: gen_id_tables.sh (create key/value table for company names and IDs)
March 25, 2023
 2H Determined how to sanitize EDI addresses at the ISA and GS levels using stock ticker symbols.
 1H Ran some code generation qurries through ChatGPT to help find options that can be used for Python+Plotly and GGI 
April 8, 2023
 5H Built code to swap out addreses for EDI as determined on March 25 with sanitize_csv.pl and sanitize.sh
 1H Wrote out Milestone 1 Detail for submission

Milestone 1 Requirements:  
April 10	Sanitized source of ASC/X12 EDI data values: Includes the collection, sanitization, and processing of year 2009 raw ASX/X12 data into a CSV formatted file that is ready for processing by the Plotly package.  Work Output - Github upload of CSV file and README file containing: milestone self-evaluation and reflection of work & intentions for the remainder of the semester

I began my project by reviewing Bokeh and Plotly/Plotly.express to determine which one I wanted to work with. I had previous expereince with Bokeh during our group project, but most of the class seemed to be leaning towards using plotly. I reviewed several places online with documentation on it. It definately seemed to be capable but also easier to understand and code with, so that is the python library I chose to use and detail out my project proposal with.

I installed the required python code on my GCP instance, created a Perl program to process my RAW EDI data into a CSV format suitable for use with Plotly. Then, I started working on some basic py scripts to make sure generation was workable for me to have acceptable output.

Later, I started to review how I would make this process interactive for the user via GGI.  At the current time, I plan to build an interactive GGI that selects the fields the user would be interested in seeing and then filter that from the archive.csv to generate the appropriate charts. I asked ChatGPT for some information GGI to refresh my memory on its use as it has been over 15 years since I last worked with it.

This weekend (4/8), I worked on getting the archive.txt file that still had company details in it sanitized. This was done by building a Perl program to swap out the fields for the stock ticker IDs from some of the Fortune 100. (a csv pulled form Kaggle)

The process so far has not been too complex, just rather time consuming to make sure that I can deliver what I have committed to -- now at 23hrs of effort and review. I feel much better about using Plotly and working with Python. This part exceeded my expetations. The time to get to this point is more than I expected, but then agian I always seem to underestimate the time required to complete complex things. It has been interesting, so the good part is that the time required felt like it it passed quickly. 

I ran into a bit of a brain block working on the sanitizing program trying to figure out a bug for about an hour. That bug turned out to be missing values in the Fortune 500 csv for stock tickers, which was causing blanks to show up in a few areas of my archive.csv file. I removed those companies from the Fortune 500 csv as those values were not relevent to my project and that resolved the issue.

As of now (Milestone 1), I now have a CSV that represents all the interchange details from the RAW EDI data I processed in my Perl program. This data is now ready for processing by my CGI (once developed) that I will be building out as the core functionality in MileStone 2.  This will call python code to generate the needed graphics.

##################################################################
Milestone 2 - April 17, 2023########################################################################
##################################################################


April 15, 2023
10H - Developed archive.pl to display a form for user input and filtering of my archive.csv dataset. Created generate.pl to process the form data, generate a query based on the form data that enables filtering archive.csv rows to a temporary output file (GUID.csv) for further processing, execute/call the child python/plotly code to read in the newly generated GUID.csv into a dataframe and output figure/html, and return this generated plotly HTML output back to the web client.  

April 16, 2023
2H - Pulled together data files, determined items of interest for professor review, and packaged a zip file with these details. 

Milestone 2 Requirements:  
April 17	
-User Integration-

1) Includes an internet accessible web form with basic authentication that accepts user input, submits it, and receives back the requested visual generation. 
	
2) A Common Gateway Interface (CGI) form processor script that receives input from the web form in (1) and calls the appropriate visual generator. (The return visual may be a dummy return for some or all returns as part of this deliverable.) Work Output - Github upload of README file containing: website URL, milestone self-evaluation, and reflection of work & intentions for the remainder of the semester. Please note, that the GCP instance is defined as SPOT as it saves costs significantly. This means that it can be brought down on demand by Google. If the host is inaccessible during evaluation, please contact dpittma5@kent.edu to have it brought back online.


Primary Artifacts of Interest:
1) archive.pl - This is a perl CGI that generates a user form and allows slecting information of interest.
2) generate.pl - This is a perl CGI that processes the form, creates a regex to filter the archive.csv dataset, calls python/plotly code, and returns its output to the browser. 
3) today.py - This python/plotly code processes the GUID.csv file as passed by argument from generate.pl.  It then reads in the filtered GUID.csv and generates HTML output. I have been swapping code fragments and changing value in of this script to see what works best visually. So far, it appears to be an area graph.
4) milestone_part1.mp4 & milestone_part2.mp4 - Video demonstrations

This week, I focused on getting bascic functionality working from end to end including submission via a CGI form, processing of parameters, generation of filter query, and visual output back from a python/plotly script. The core of my project is now complete. I next need to work on further enabling desired features and enhancing/revising the visual options of the python/plotly code for best visuals. 

As to be expected when coding, a lot of my time consisted of editing and tracking down bugs. I was happy to finally get a working model this week as there was a lot of effort ancillary to actually getting to where the plotly code could be the focus. That was a major hurdle to get all the pieces working ... together.

Over the next week, I will be looking over the varius options for filtering my dataset (archive.pl) and then how to best display that via python/plotly code. The next two weeks before my milestone3 delivery will be about tweaking the perl and python/plotly code for best visuals.
##################################################################
Milestone 3 - May 1, 2023###########################################################################
##################################################################
April 18  
3H - In class workday 
During the day, I decided that the way my chart was being displayed as stacked area didn't look good.  I converted it to two separate lines. (red and green) During class I worked on cleaning/enhancing how the output looked and updated the line colors to red/blue for the visually impaired
April 22 
2H
I reviewed different options and querries on Google and chatGPT to see if I could come up with better looking output
April 27
4H
Saturday AM, I  added in Dr. Silva's suggestion from 5/23 about a third line that showed where I thought an alert threshold should be. I also thought again about my Foundations of EMAT class (and this class) with respect to making information displayed readily understandable without having to work at at. So, I made the alert line gray, very thin and dotted; the average line blue and a little bit thicker, and the focal point of the red line, much thicker. After playing around with it for a bit, I found the right size that made it stand out and still showed the marker/plot points.
May 1
2h
I pulled together and animated gif of my current site and output, downloaded an html output from plotloy before it is loaded into its webpage response, and then created this README.

Primary Artifacts of Interest:
1) line.py - This python/plotly code processes the GUID.csv file as passed by argument from generate.pl.  It then reads in the filtered GUID.csv and generates HTML output. I seem to have settled on three lines. One for the average in blue, one for the day plot in red, and one for a max threshold.  This is getting close to final product.
2) milestone3_animated.gif & milestone3_plotly_output.html - Work output for review

The last two weeks, I focused on getting better visual output back from python/plotly . The core of my project is now complete. I plan to work on updating the archive and generate perl programs a bit this last week before presentations to make them a bit more visually appealing. I think I have my graph working as I want it, but may tinker a bit more to see if I can do anything else of note.

As with milestone 2, a lot of my time consisted of editing and tracking down bugs. The last two weeks, it was in python/plotly code. When I wouldn't get a return from my CGI after making changes, I would have to track down what didn't play nice, attempt a fix, and refresh my broweser to see if I received a graph.

Over the next week, I'll mostly be cleaning up and finalizing along with generation a powerpoint for my final presentation. That will likely consist of how I built the work product,some excerpts of code, and a demo.


##################################################################
Final Project/Report and Presentation - May 9, 2023###########################################################################
##################################################################
May 4 3h
Created and added embedded logo into archive.pl and generate.pl
Created webm video captures of Example1(Normal Data) and Example2(Exceeded Thresholds) Plotly Expres graphs
Downloaded Example1 and Example2 Plotly generated html files
Collected, generated, and organized artifacts for presenation

May 5 / 2h PowerPoint presenation development
May 8 / 30m Pull final project artifacts together into a zip and load to git
May 8 / 10m Load presentation to git
My primary focus after Milestone 3 was preparation for final project and presentation submission. No real issues were encountered in this stage ... it just took time to collect and prepare everything.

#####

Final Report: (also generated in DOC format if preferred)
“Electronic Data Interchange (EDI) is the computer-to-computer exchange of business documents in a standard electronic format between business partners” (What is EDI). My project, EDI Data Charter is a web application that enables a graphical display of Electronic Data Interchange (EDI) messages represented by Sender, Receiver, Document Type, and Date. The application is designed for smaller businesses that do not have access to graphical information about their data flows. Feeding data in this application from a client's chosen EDI system enables a graphical view of EDI data messages processed by Sender, Receiver, Document Type, and Date. This is helpful, but what it only shows what was processed today or a prior day. The real benefit is seeing a plot of a day's volume (in red) compared against two other values. The first (in blue), shows the mean of daily volumes processed on the same weekday, and the second (in grey), a high water marker or threshold for concern. The blue line enables the current day's volume in red to be compare against all prior same weekdays.  The grey line, enables a quick reference to see if the days value in red is significantly more than expected and a possible cause for alarm.

My data sources were from an archive of EDI data for a project I worked on in 2009; however, the EDI data content had private information in it. My Milestone 1 required the creation of some shell and Perl scripts to process the raw EDI, extract the fields I needed to a CSV, and then sanitize them using a download of company names and stock tickers. These company names and IDs were substituted for the EDI addresses found in my non-sanitized CSV output. Once a company name/ID was selected, it was then used for all further data processed that matched that same EDI ID. I was then able to create a sanitized CSV that uses alternate company names and IDs. As I had complete control over the build of my data source (from my archvied raw data), I was able to create my CSV data source in the format I desried. The quality of the data was then assured as long as I generated it correctly.  The structure of the final output CSV dataset was in the format and order of the enveloping structure of EDI data, so I was logical for me to extract and process any resultant information in Python/Plotly Express.

My project uses Linux on Google Cloud Platform, Python & Plotly Express, HTML, and Perl (Practical Extraction and Reporting Language) & BASH (Borne Again Shell). 
Linux on GCP was used as the platform to host the web application for development and use vs Jupyter Notebook.

For the core of my project, I built a base level Common Gateway Interface (CGI) program in Perl that was hosted in the cgi-bin directory on a Nginx web server I deployed. My first Perl program (archive.pl) generates the form for user input. It then passes that output to another Perl program (generate.pl). This program calls a generic Python/Plotly Express child program from a subroutine in the Perl CGI. Once that base level of code was completed, I could then make updates to the Perl variables passed to the CGI and to the Python+Plotly Express program and display the results in my web browser (similar to the way Jupyter Notebook works) for my development efforts.

Still early in the project, in Milestones 2, I then mainly worked on creating functionality in my Python/Plotly Express code through various iterations to accurately represent my design idea showing how a specific day's message volume flow looks graphically vs a mean. As I progressed through the milestones, I could definitely see the clarity and focus of my design improving. This requires significant review and work over the following milestones to create an engaging visualization. My first attempt(s) looked reasonable, but were not as clean, polished, and informative as they could be.

I was able to spend time and review concepts for organizing and analyzing data my data in a visually appealing manner, but it took many iterations and checking against various data reference sources to find what I needed to make my chart more visually appealing and display what was needed to convey the information about EDI message volumes.

Then later, for Milestone 3, I was able to cleanup my final design, add a grey dotted line representing an alert threshold (where concern may be if message volume for a chosen day exceeds this value for Dr. Silva's suggestion and then find features that smoothed my lines into more curved shapes and enabled dark mode. This made it look more professional and better met my audience's needs -- to see both the data they were interested in and other details that would better enable interpretatin in a clear and immediate manner. Is the flow normal? Check 1, is is somewhat like the daily average in blue?  Check 2, does it exceed the grey concern/alerting threshold line? If not, then the data flow for this day is "normal".  If not, then it is abnormal and cause for at leasr some level of concern and review.

Finally, in preparation for my final project submission, I added a logo and cleaned up my comments and code. For my presentation, I added screenshots of my graphs, video demonstrations, HTML files that can be interactively explored, and a summary of my project for later review by others.

I did run into some limitations with using Python/Plotly Express. Bending the chart look and feel to the way I wanted it was possible for some things like color, title, chart and/or line styles, but other things were not as easy ... at least not without a lot more custom Python code (and Python coding understaing) making more significant changes to how the data looks. During development, I also tried multiple chart types and approaches to make my date be clearly understood to my audience -- business users and EDI system administrators. I think I reached that goal. 

In the future, I left several avenues open for further exploration. The Perl archive.pl script has additional form fields that I commented out due to not wanting them in this first version.  This includes chart type (for other possible views of the data), a date range by week/month/year versus just a single day, or possibly allowing for the alert threshold to be toggled higher or lower as another option.  Lastly, this was a view into the past as that is the data I had to work with. Most users want data accurate to now. I would need to setup a watcher program to feed new data from my archiveInfo.pl Perl prgram that collects and loads new lines to my archive.csv dataset. This last step when working with live data would make it userful for finding how data is not only performing today, but also at another day in the past to see how they compare with each other directly.

Overall, it was a lot to take in over the 15 class periods available during the semester. Earlier focus on Plotly would have helped me be more comfortable sooner, but by the end I feel reasonably confident in being able to work out what I need to do next, find out how and update code as necessary, and then create output that is usable my my target audience. In the end, I think the output looks good and shows what I intended.




