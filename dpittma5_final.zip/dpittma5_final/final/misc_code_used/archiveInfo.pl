#!/usr/bin/perl
# Title: archive.pl
# Author: David Pittman
# Created: March 18, 2023
#
####################################################
use Time::Piece;


# Open up the data and load it to a variable 
open( FILE, "<$ARGV[0]" );
while ( $x = <FILE> ) { $data .= $x; }
close(FILE);


# Remove null if any are found in the data
$data =~ tr/\0//d;

# Capture the time we process the EDI interchange
($Second, $Minute, $Hour, $DayOfMonth, $Month, $Year, $WeekDay, $DayofYear, $IsDST) = localtime(time);
$RealMonth = $Month + 1;
$RealYear = $Year + 1900;
if (length($DayOfMonth) eq 1) { $DayOfMonth = "0$DayOfMonth"; }
if (length($RealMonth) eq 1) { $RealMonth = "0$RealMonth"; }
if (length($Hour) eq 1) { $Hour = "0$Hour"; }
if (length($Minute) eq 1) { $Minute = "0$Minute"; }
$time = "$RealYear$RealMonth$DayOfMonth$Hour$Minute";   

# Get the length of the data 
$fileSize = length($data);


# Split apart data into individual documents and place each doc as an individual
# element on an array
# Pattern to look for (magic type)					# EDI Format Type
# ---------------------------------------------------------------------------------------
$data =~ s/(ISA.[0-9][0-9]............[0-9][0-9].)/\0${1}/g;# ASC/X12   # ASC X12

# Split the data at the beginning of each document now marked with a \0 tag
@interchangeArray = split ( /\0/, $data );
$messageNumber = 1;

# Remove byproduct junk element/artifact from splitting on nulls from the new array 
shift @interchangeArray;

# Take each individual ISA/IEA envelope off the @interchangeArray and process one at a time.
foreach $message (@interchangeArray) {

# Get the EDI document type (ISA=X12)
$ediType = substr( $message, 0, 3 );

# If the datatype EDI X12/EDI
if ( $ediType eq "ISA" ) {
 # X12 data type found

        # Set-up delimeters within the EDI data
        $seg = substr( $message, 105, 1 );
        $segDelim = quotemeta $seg;

        $elem = substr( $message, 103, 1 );
        $elemDelim = quotemeta $elem;

	#Split the ISA/IEA document we are now working with into individual segments for processing.
        @segArray = split ( /$segDelim/, "$message" );

	foreach $segmentLine (@segArray) {
	   @segLineArray = split( /$elemDelim/, $segmentLine);

	   # Get the first element/segnent type
	   $segType = $segLineArray[0];
	   if ($segType eq "ISA")
	   {
	   # Extract ISA information 
	   $icgSenderQual = $segLineArray[5];
	   $icgSender = $segLineArray[6];
	   $icgSender =~ s/ *$//g;
	   $icgSender =~ s/^ *//g;
	   $icgReceiverQual = $segLineArray[7];
	   $icgReceiver = $segLineArray[8];
	   $icgReceiver =~ s/ *$//g;
	   $icgReceiver =~ s/^ *//g;
	   $icgCtrlNum = $segLineArray[13];
	   # Pandas Date/Time Format 2011-01-01 00:00:00
	   $icgDate = $segLineArray[9];
	    if (! substr( $icgDate, 0, 20) ne "20") 
		     {$icgDate = "20" . $icgDate;} # Make sure we are a 4 digit year. Good through end of 2099
	   $icgYear = $icgDate;
	   $icgMonth = $icgDate;
	   $icgDay = $icgDate;
	   $icgDate =~ s/([0-9]{4})([0-9]{2})([0-9]{2})/$1-$2-$3/g;
	   $icgYear =~ s/([0-9]{4})([0-9]{2})([0-9]{2})/$1/g;
	   $icgMonth =~ s/([0-9]{4})([0-9]{2})([0-9]{2})/$2/g;
	   $icgDay =~ s/([0-9]{4})([0-9]{2})([0-9]{2})/$3/g;
	   $icgTime = $segLineArray[10];
	   $icgTime =~ s/([0-9]{2})([0-9]{2})/$1:$2:00/g;
	   $pandasTime = "$icgDate $icgTime";
	   # Convert icgDate to day of week
	   $date = Time::Piece->strptime($icgDate, '%Y-%m-%d');
	   @weekdayNames = qw(Sunday Monday Tuesday Wednesday Thursday Friday Saturday);
	   $dayOfWeek = $date->day_of_week;
           $weekdayName = $weekdayNames[$dayOfWeek];
	   $weekOfYear = $date->strftime('%U');
           }
	   elsif ($segType eq "GS")
	   {
	   # Extract GS Information
	   $grpType = $segLineArray[1];
	   $grpSender = $segLineArray[2]; 
           $grpSender =~ s/ *$//g;
           $grpSender =~ s/^ *//g;
           $grpReceiver = $segLineArray[3];
           $grpReceiver =~ s/ *$//g;
           $grpReceiver =~ s/^ *//g;
           $grpCtrlNum = $segLineArray[6];
           $grpVersion = $segLineArray[8];
	   $grpSize = length($segmentLine) + 1;
           }
	   elsif ($segType eq "ST")
	   {
	   # Extract ST Information
           $msgType = $segLineArray[1];
	   $grpSize = $grpSize + length($segmentLine) + 1;
           }
	   elsif ($segType eq "SE")
	   {
	           $grpSize = $grpSize + length($segmentLine) + 1;
		   $stSegments = $stSegements + $segLineArray[1];
	   }
	   elsif ($segType eq "GE")
	   {
		   # Print out captured info
		   $stCount = $segLineArray[1];
	           $grpSize = $grpSize + length($segmentLine) + 1;
		   print "$icgSenderQual:$icgSender,$icgReceiverQual:$icgReceiver,$icgCtrlNum,$pandasTime,$grpSender,$grpReceiver,$grpType,$grpCtrlNum,$grpVersion,$msgType,$stCount,$stSegments,$grpSize,$icgYear,$icgMonth,$icgDay,$weekOfYear,$weekdayName\n";
		   undef($stSegments);
	   }
	   elsif ($segType eq "IEA")
	   {
	   }
	   else
	   {
	   $grpSize = $grpSize + length($segmentLine) + 1;
           }
        } # End of segLine foreach
}


# Increment the message number count
$messageNumber++;
} # End of foreach loop
