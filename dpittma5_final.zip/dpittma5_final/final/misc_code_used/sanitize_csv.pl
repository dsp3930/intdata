#!/usr/bin/perl


open( COMPANY, "companyToEdiName.tbl" );
while ( $segment = <COMPANY> ) 
{
	chomp $segment;  # Remove linefeed
	@segElements = split(/\,/,$segment); # Split apart the csv line into segments by comma separated element
	$coHash{$segElements[1]} = $segElements[0];  # Create a hash with keys of StockTickerSymbol and values of Full Company Name
	# ABCD = "Company Name"
	push @coArray,$segElements[1];
}
close(COMPANY);

#Open sender/receiver/doctype.tbl for output
open( SENDER, ">sender.tbl" );
open( RECEIVER, ">receiver.tbl" );
open( DOC, ">doctype.tbl" );

# Open up the data and loop over each line
$count=0;
open( CSV, "<$ARGV[0]" );
while ( $segment = <CSV> ) 
{
	chomp $segment;  # Remove linefeed
	@segElements = split(/\,/,$segment); # Split apart the csv line into segments by comma separated element
	# Replace Interchange Sender and Group Sender with new Company ID
	#if (defined($sanitize{$segElements[0]}))
	if (length($sanitize{$segElements[0]}) > 0)
        {
	$segment =~ s/$segElements[0]/ZZ:$sanitize{$segElements[0]}/;
	$segment =~ s/$segElements[4]/$sanitize{$segElements[0]}/;
	}
	else
	{
        $sanitize{$segElements[0]} = $coArray[$count];
	$key = $sanitize{$segElements[0]};
	print SENDER "ZZ:$sanitize{$segElements[0]},$coHash{$key}\n";
	print DOC "$segElements[9]\n";
	$count++; # Increment the counter for the next company name and symbol to use
	$segment =~ s/$segElements[0]/ZZ:$sanitize{$segElements[0]}/;
	$segment =~ s/$segElements[4]/$sanitize{$segElements[0]}/;
	}
	# Replace Interchange Receiver and Group Receiver with new Company ID
	#if (defined($sanitize{$segElements[1]}))
	if (length($sanitize{$segElements[1]}) > 0)
        {
	$segment =~ s/$segElements[1]/ZZ:$sanitize{$segElements[1]}/;
	$segment =~ s/$segElements[5]/$sanitize{$segElements[1]}/;
	}
	else
	{
        $sanitize{$segElements[1]} = $coArray[$count];
	$key = $sanitize{$segElements[1]};
	print RECEIVER "ZZ:$sanitize{$segElements[1]},$coHash{$key}\n";
	print DOC "$segElements[9]\n";
	$count++; # Increment the counter for the next company name and symbol to use
	$segment =~ s/$segElements[1]/ZZ:$sanitize{$segElements[1]}/;
	$segment =~ s/$segElements[5]/$sanitize{$segElements[1]}/;
	}
	print "$segment\n";
}
close(CSV);
close(SENDER);
close(RECEIVER);
close(DOC);


