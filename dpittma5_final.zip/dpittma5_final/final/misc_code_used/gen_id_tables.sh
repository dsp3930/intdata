#!/bin/sh
# Modify Fortune_1000.csv to make company names ISA 15 char compliant 
if test -f companyToEdiName.tbl
then
	rm -rf companyToEdiName.tbl
fi

cat Fortune_1000.csv | while read x
do
companyName=`echo "$x"|cut -f1 -d ","||tr ',' ' '|tr -d '\n'`
companyTicker=`echo "$x"|rev|cut -f2 -d ","|rev|tr -d '\n'`
echo "$companyName,$companyTicker" >> companyToEdiName.tbl
# Make sure to manually remove companies that do not have a stock ticker symbol
done

