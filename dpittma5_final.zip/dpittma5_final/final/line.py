#!/usr/bin/python3.9
# Auth: David Pittman
# File: line.py
# Desc: Takes in id and date, then generates a python/plotly.express line chart
# The chart shows average messages per hour, messages per hour on specified day,
# and alert threhold limit for daily messages
# Ver: 20230501
##########################
import plotly
import plotly.express as px
import pandas as pd
import sys

# Read in variables passed from CGI
id = sys.argv[1]
date = sys.argv[2]

# read in CSV file
csv = f'/home/dsp3930/tmp/{id}.csv'

#Column format for archive.csv
#Interchange Sender,Interchange Receiver,Interchange Control Number,Interchange Timestamp,Group Sender,
#Group Receiver,Group Type,Group Control Number,Group Version,Message Type,Message Count,Message Segments,
#Content Size,Year,Month,Day,Week of Year,Day Name

# Read the CSV file into a pandas dataframe
df = pd.read_csv(csv)

# Convert the 'Interchange Timestamp' column to datetime format
df['Interchange Timestamp'] = pd.to_datetime(df['Interchange Timestamp'])

# Extract the hour from the 'Interchange Timestamp' column and add it as a new column
df['Hour Of Day'] = df['Interchange Timestamp'].dt.hour

# Filter the dataframe to only include rows where the date matches the 'Interchange Timestamp' date
df_date = df[df['Interchange Timestamp'].dt.date == pd.to_datetime(date).date()]

# Calculate the average message count grouped by 'Hour Of Day' for all dataframe rows
df_avg = df.groupby('Hour Of Day', as_index=False).mean()

# Define a figure using px.area
fig = px.area()

# Add a dotted line for the max problem value thredhold above the average message count for all dataframe rows in gray
fig.add_scatter(x=df_avg.groupby('Hour Of Day')['Message Count'].mean().index,
                y=df_avg.groupby('Hour Of Day')['Message Count'].mean().values * 4.5,
                mode='lines',
                line=dict(color='gray', width=1, dash='dot', shape='spline'),
                name='Potential Issue Threshold',
                hovertemplate='Hour of Day: %{x}<br>Upper Bound: %{y:.1f}')

# Add a line showing the counts grouped by 'Hour Of Day' for the specified date in red
fig.add_scatter(x=df_date.groupby('Hour Of Day')['Message Count'].mean().index,
                y=df_date.groupby('Hour Of Day')['Message Count'].mean().values,
                mode='lines+markers',
                line=dict(color='red', width=4, shape='spline'),
                name='Message Count for ' + date,
                hovertemplate='Hour of Day: %{x}<br>Message Count: %{y}')
                
# Add a line showing the mean of message count grouped by 'Hour Of Day' for the specified date in blue
fig.add_scatter(x=df_avg.groupby('Hour Of Day')['Message Count'].mean().index,
                y=df_avg.groupby('Hour Of Day')['Message Count'].mean().values * 2,
                mode='lines',
                line=dict(color='blue', width=2, shape='spline'),
                name='Message Count Average',
                hovertemplate='Hour of Day: %{x}<br>Average Message Count: %{y:.1f}')

# Set the chart title and axis labels, size for window changes, use dark theme, and set x gridlines to every 3 hrs
fig.update_layout(title='Message Count by Hour of Day',
                  xaxis_title='Hour Of Day',
                  yaxis_title='Message Count',
                  title_x=0.5,
                  autosize=True,
                  template='plotly_dark',
                  xaxis=dict(tickmode='linear', dtick=3))

# Save the chart as an html page for deplay back to client
# CGI will then capture the output HTML using a GUID/UUID that was passed to this program and display it back to user
htmlOutput = f'/home/dsp3930/tmp/{id}.html'
fig.write_html(htmlOutput)
